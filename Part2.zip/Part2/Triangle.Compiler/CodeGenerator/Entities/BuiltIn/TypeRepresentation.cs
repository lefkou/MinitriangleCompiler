namespace Triangle.Compiler.CodeGenerator.Entities
{
    public class TypeRepresentation : RuntimeEntity
    {

        public TypeRepresentation(int size)
            : base(size)
        {
        }

    }
}