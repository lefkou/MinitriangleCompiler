# Triangle Tools in C#

This is a C# version of the Triangle Tools (compiler, disassembler and interpreter) used in the textbook:

"Programming Language Processors in Java" by D.A. Watt and D.F. Brown, Pearson (2000).

