/**
 * @Author: Eleftherios Kousis <lef>
 * @Date:   5-Nov-2017
 * @Filename: Parser - TypeDenoters.cs
 * @Last modified by:   lef
 * @Last modified time: 5-Nov-2017
 */




namespace Triangle.Compiler.SyntacticAnalyzer
{
    public partial class Parser
    {
        void ParseTypeDenoter()
        {
            System.Console.WriteLine("parsing type denoter");
            ParseIdentifier();
        }
    }
}